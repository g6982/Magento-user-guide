# -*- coding: utf-8 -*-
{
    'name': "WooCommerce Net Profit Report Ept",

    'summary': """
        Visible Net Profit report for WooCommerce all instances.""",

    'description': """
        Visible Net Profit report for WooCommerce all instances.
    """,

    'author': "Emipro Technologies Pvt. Ltd.",
    'website': "http://www.emiprotechnologies.com",

    'license': 'OPL-1',
    'category': 'Account',
    'version': '0.1',

    'depends': ['account_accountant', 'woo_commerce_ept'],

    'data': [
        'data/woo_net_profit_report_data.xml',
        'report/net_profit_report.xml',

    ],
}
